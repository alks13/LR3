package com.example.androidlab3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    TextView nameView;
    TextView yearView;
    TextView genreView;
    TextView aboutView;

    Button backButton;

    String name;
    int year;
    String genre;
    String about;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_detail);

        nameView = (TextView) findViewById(R.id.name);
        yearView = (TextView) findViewById(R.id.year);
        genreView = (TextView) findViewById(R.id.genre);
        aboutView = (TextView) findViewById(R.id.about);

        backButton = (Button) findViewById(R.id.backButton);

        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        year = intent.getIntExtra("year", 0);
        genre = intent.getStringExtra("genre");
        about = intent.getStringExtra("about");

        nameView.setText(name);
        yearView.setText("Дата основания: " + year);
        genreView.setText("Жанр: " + genre);
        aboutView.setText(about);
    }

    public void backClick(View view) {
        Intent intent = new Intent();
        intent.setClass(DetailActivity.this, MainActivity.class);
        startActivity(intent);
    }
}
