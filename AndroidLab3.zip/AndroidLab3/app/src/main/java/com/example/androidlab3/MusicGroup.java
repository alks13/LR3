package com.example.androidlab3;

public class MusicGroup {
    private String name;
    private int year;
    private String genre;
    private String about;

    public MusicGroup(String name, int year, String genre, String about) {
        this.name = name;
        this.year = year;
        this.genre = genre;
        this.about = about;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }

    public String getGenre() {
        return genre;
    }

    public String getAbout() {
        return about;
    }

    @Override
    public String toString() {
        return name + "\n" + genre + "\t" + year;
    }
}
