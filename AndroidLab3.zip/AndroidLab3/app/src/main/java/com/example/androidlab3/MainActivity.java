package com.example.androidlab3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    MusicGroup[] groups = {
            new MusicGroup("AC/DC", 1973, "Хард-рок",
            "австралийская рок-группа, сформированная в Сиднее в ноябре 1973 года выходцами"+
                    " из Шотландии, братьями Малькольмом и Ангусом Янгами. "),
            new MusicGroup("Daft Punk", 1993, "Техно",
                    " французский музыкальный электронный дуэт, образованный в 1993 году" +
                            " Томой Бангальтером и Ги-Мануэлем де Омем-Кристо.")
    };

    List<String> infoAboutGroups = getInfo();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                        infoAboutGroups));
        listView.setTextFilterEnabled(true);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, DetailActivity.class);
                intent.putExtra("name", groups[position].getName());
                intent.putExtra("year", groups[position].getYear());
                intent.putExtra("genre", groups[position].getGenre());
                intent.putExtra("about", groups[position].getAbout());
                startActivity(intent);
            }
        });
    }

    public List<String> getInfo() {
        List<String> result = new ArrayList<>();
        for (MusicGroup group : groups) {
            result.add(group.toString());
        }
        return result;
    }
}